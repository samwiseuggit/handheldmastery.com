import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, "./src") } },
  build: {
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, "index.html"),
        compare: path.resolve(__dirname, "compare.html"),
        blog: path.resolve(__dirname, "blog.html"),
        toolbox: path.resolve(__dirname, "toolbox.html"),
        monetization: path.resolve(__dirname, "monetization.html"),
        sitemap: path.resolve(__dirname, "sitemap.html"),
      },
    },
    outDir: "dist", assetsDir: "assets", emptyOutDir: true,
  },
});
