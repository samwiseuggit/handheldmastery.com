import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Layout from "@/components/Layout";
import ToolboxPage from "@/pages/ToolboxPage";
import "@/index.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Layout active="toolbox">
      <ToolboxPage />
    </Layout>
  </StrictMode>
);
