import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Layout from "@/components/Layout";
import BlogPage from "@/pages/BlogPage";
import "@/index.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Layout active="blog">
      <BlogPage />
    </Layout>
  </StrictMode>
);
