import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Layout from "@/components/Layout";
import HomePage from "@/pages/HomePage";
import "@/index.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Layout active="home">
      <HomePage />
    </Layout>
  </StrictMode>
);
