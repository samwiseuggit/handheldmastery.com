import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import Layout from "@/components/Layout";
import SitemapPage from "@/pages/SitemapPage";
import "@/index.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <Layout active="sitemap">
      <SitemapPage />
    </Layout>
  </StrictMode>
);
