import { useState, useMemo } from "react";
import { Search, Star, ExternalLink, X, Filter } from "lucide-react";
import { products, getBestPrice, type Product } from "@/data/products";
import AdSlot from "@/components/AdSlot";

type SortOption = "price-asc" | "price-desc" | "rating" | "name";

function ProductModal({ product, onClose }: { product: Product; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <div><span className="text-xs font-medium text-cyan-400 uppercase tracking-wide">{product.subcategory}</span><h2 className="text-xl font-bold text-white mt-1">{product.name}</h2></div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">{Array.from({length:5}).map((_,i)=>(<Star key={i} className={`w-5 h-5 ${i<Math.round(product.rating||0)?"text-amber-400 fill-amber-400":"text-slate-600"}`}/>))}<span className="text-slate-300 ml-2">{product.rating}/5</span></div>
            <div className="text-2xl font-bold text-white">${getBestPrice(product)}</div>
          </div>
          <div><h3 className="text-sm font-semibold text-slate-300 mb-3 uppercase tracking-wide">Key Specs</h3><div className="grid grid-cols-2 gap-2">{Object.entries(product.keySpecs).map(([k,v])=>(<div key={k} className="bg-slate-800/50 rounded-lg p-3"><div className="text-xs text-slate-500 capitalize">{k.replace(/([A-Z])/g," $1")}</div><div className="text-sm text-slate-200 font-medium">{v}</div></div>))}</div></div>
          <div><h3 className="text-sm font-semibold text-slate-300 mb-3 uppercase tracking-wide">Price Comparison</h3><div className="space-y-2">{Object.entries(product.price).filter(([,v])=>typeof v==="number"&&v>0).sort(([,a],[,b])=>(a as number)-(b as number)).map(([r,p])=>(<div key={r} className="flex items-center justify-between bg-slate-800/50 rounded-lg p-3"><span className="text-sm text-slate-300 capitalize">{r==="msrp"?"MSRP":r}</span><span className={`text-sm font-bold ${r==="msrp"?"text-slate-400":"text-white"}`}>${p as number}</span></div>))}</div></div>
          <div><h3 className="text-sm font-semibold text-slate-300 mb-3 uppercase tracking-wide">Where to Buy</h3><div className="flex flex-wrap gap-2">{Object.entries(product.retailerLinks).filter(([,u])=>u).map(([r,u])=>(<a key={r} href={u} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 bg-violet-600 hover:bg-violet-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">{r==="jsaux"?"JSAUX":r==="direct"?"Direct":r.charAt(0).toUpperCase()+r.slice(1)}<ExternalLink className="w-3.5 h-3.5"/></a>))}</div></div>
          <div className="bg-cyan-500/5 border border-cyan-500/20 rounded-lg p-4"><h3 className="text-sm font-semibold text-cyan-400 mb-1">Best For</h3><p className="text-sm text-slate-300">{product.bestFor}</p></div>
        </div>
      </div>
    </div>
  );
}

export default function ComparisonPage() {
  const [category, setCategory] = useState("all");
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<SortOption>("price-asc");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const filtered = useMemo(() => {
    let list = category === "all" ? products : products.filter(p => p.category === category);
    if (search.trim()) { const q = search.toLowerCase(); list = list.filter(p => p.name.toLowerCase().includes(q) || p.subcategory.toLowerCase().includes(q) || p.bestFor.toLowerCase().includes(q) || Object.values(p.keySpecs).some(v => v.toLowerCase().includes(q))); }
    return [...list].sort((a, b) => { switch (sortBy) { case "price-asc": return getBestPrice(a) - getBestPrice(b); case "price-desc": return getBestPrice(b) - getBestPrice(a); case "rating": return (b.rating || 0) - (a.rating || 0); case "name": return a.name.localeCompare(b.name); default: return 0; } });
  }, [category, search, sortBy]);
  const catCount = (id: string) => id === "all" ? products.length : products.filter(p => p.category === id).length;
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-white mb-2">Product Comparison</h1>
      <p className="text-slate-400 mb-8">Compare 50+ handheld gaming products with real-time pricing and specs.</p>
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500"/><input type="text" placeholder="Search products, specs, use cases..." value={search} onChange={e => setSearch(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"/></div>
        <div className="flex items-center gap-2"><Filter className="w-4 h-4 text-slate-500"/><select value={sortBy} onChange={e => setSortBy(e.target.value as SortOption)} className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2.5 text-slate-100 text-sm focus:outline-none focus:border-cyan-500"><option value="price-asc">Price: Low to High</option><option value="price-desc">Price: High to Low</option><option value="rating">Highest Rated</option><option value="name">Name A-Z</option></select></div>
      </div>
      <div className="flex flex-wrap gap-2 mb-4">
        {[{id:"all",label:"All"},{id:"console",label:"Consoles"},{id:"power",label:"Power Solutions"},{id:"storage",label:"Storage"},{id:"dock",label:"Docks & Hubs"},{id:"peripheral",label:"Peripherals"}].map(c => (
          <button key={c.id} onClick={() => setCategory(c.id)} className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${category === c.id ? "bg-violet-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}>{c.label} ({catCount(c.id)})</button>
        ))}
      </div>
      <div className="text-sm text-slate-500 mb-4">{filtered.length} products found</div>

      {/* ─── INLINE 300x250 AD ─── */}
      <AdSlot type="banner-300" id="compare-inline-mid" />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {filtered.map(p => (
          <button key={p.id} onClick={() => setSelectedProduct(p)} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-cyan-500/50 transition-colors text-left">
            <div className="text-xs font-medium text-cyan-400 uppercase tracking-wide mb-1">{p.subcategory}</div>
            <h3 className="text-white font-semibold text-sm mb-2">{p.name}</h3>
            <div className="flex items-center gap-1 mb-2">{Array.from({length:5}).map((_,i)=>(<Star key={i} className={`w-3.5 h-3.5 ${i<Math.round(p.rating||0)?"text-amber-400 fill-amber-400":"text-slate-600"}`}/>))}<span className="text-xs text-slate-400 ml-1">{p.rating}</span></div>
            <div className="text-lg font-bold text-white">${getBestPrice(p)}</div>
            <div className="text-xs text-slate-500 mt-1 line-clamp-1">{p.bestFor}</div>
            <div className="mt-3 flex flex-wrap gap-1">{Object.entries(p.keySpecs).slice(0,3).map(([k,v]) => <span key={k} className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">{v}</span>)}</div>
          </button>
        ))}
      </div>
      {selectedProduct && <ProductModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />}
    </div>
  );
}
