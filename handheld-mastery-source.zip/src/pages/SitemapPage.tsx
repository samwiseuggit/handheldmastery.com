import { Map, MapPin, FileText, BarChart3, Wrench, DollarSign } from "lucide-react";
import { articles } from "@/data/articles";
import { products, categories } from "@/data/products";
import AdSlot from "@/components/AdSlot";

export default function SitemapPage() {
  const blogArticles = articles.filter(a => a.category === "blog");
  const howtoArticles = articles.filter(a => a.category === "howto");
  const versusArticles = articles.filter(a => a.category === "versus");
  const blogColor = "text-cyan-400"; const howtoColor = "text-emerald-400"; const versusColor = "text-violet-400";
  const blogBg = "bg-cyan-500/10"; const howtoBg = "bg-emerald-500/10"; const versusBg = "bg-violet-500/10";
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center py-12 mb-8">
        <Map className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
        <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Site Map</h1>
        <p className="text-slate-400 max-w-2xl mx-auto">Complete directory of all pages, articles, and resources on Hand Held Mastery.</p>
      </div>

      {/* ─── INLINE 300x250 AD ─── */}
      <AdSlot type="banner-300" id="sitemap-inline-top" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><BarChart3 className="w-5 h-5 text-violet-400" /> Main Pages</h2>
          <div className="space-y-2">
            {[{href:"index.html",label:"Home — Featured products, articles, and tools"},{href:"compare.html",label:`Compare — ${products.length} products with pricing and specs`},{href:"blog.html",label:`Blog — ${articles.length} articles across 3 categories`},{href:"toolbox.html",label:"Toolbox — Software and optimization tools"},{href:"monetization.html",label:"Affiliate Hub — Monetization resources"},{href:"sitemap.html",label:"Site Map — This page"}].map(link => (
              <a key={link.href} href={link.href} className="flex items-center gap-2 text-slate-300 hover:text-cyan-400 transition-colors py-1.5"><MapPin className="w-4 h-4 text-slate-500" /><span className="text-sm">{link.label}</span></a>
            ))}
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><BarChart3 className="w-5 h-5 text-cyan-400" /> Product Categories</h2>
          <div className="space-y-2">
            {categories.map(cat => (
              <a key={cat.id} href="compare.html" className="flex items-center justify-between text-slate-300 hover:text-cyan-400 transition-colors py-1.5"><span className="text-sm capitalize">{cat.label}</span><span className="text-xs text-slate-500">{products.filter(p => p.category === cat.id).length} products</span></a>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><FileText className={`w-5 h-5 ${blogColor}`} /> Blog Articles ({blogArticles.length})</h2>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2">
            {blogArticles.map(a => (
              <a key={a.slug} href={`./articles/${a.slug}.html`} className="block text-sm text-slate-300 hover:text-cyan-400 transition-colors py-1 border-b border-slate-800/50 last:border-0"><span className={`text-xs ${blogBg} ${blogColor} px-1.5 py-0.5 rounded mr-2`}>{a.categoryLabel}</span>{a.title}</a>
            ))}
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Wrench className={`w-5 h-5 ${howtoColor}`} /> How-To Guides ({howtoArticles.length})</h2>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2">
            {howtoArticles.map(a => (
              <a key={a.slug} href={`./articles/${a.slug}.html`} className="block text-sm text-slate-300 hover:text-emerald-400 transition-colors py-1 border-b border-slate-800/50 last:border-0"><span className={`text-xs ${howtoBg} ${howtoColor} px-1.5 py-0.5 rounded mr-2`}>{a.categoryLabel}</span>{a.title}</a>
            ))}
          </div>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><BarChart3 className={`w-5 h-5 ${versusColor}`} /> Versus Comparisons ({versusArticles.length})</h2>
          <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2">
            {versusArticles.map(a => (
              <a key={a.slug} href={`./articles/${a.slug}.html`} className="block text-sm text-slate-300 hover:text-violet-400 transition-colors py-1 border-b border-slate-800/50 last:border-0"><span className={`text-xs ${versusBg} ${versusColor} px-1.5 py-0.5 rounded mr-2`}>{a.categoryLabel}</span>{a.title}</a>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-8">
        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><DollarSign className="w-5 h-5 text-amber-400" /> Stats at a Glance</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[{label:"Total Pages",value:"37"},{label:"Products",value:products.length.toString()},{label:"Articles",value:articles.length.toString()},{label:"Categories",value:"5"}].map(s => (
            <div key={s.label} className="text-center p-4 bg-slate-800/50 rounded-lg"><div className="text-2xl font-bold text-white">{s.value}</div><div className="text-xs text-slate-400">{s.label}</div></div>
          ))}
        </div>
      </div>

      {/* ─── NATIVE AD ─── */}
      <AdSlot type="native" id="sitemap-native-bottom" />
    </div>
  );
}
