import { useState } from "react";
import { ExternalLink, Wrench, Settings } from "lucide-react";
import { softwareTools } from "@/data/products";
import AdSlot from "@/components/AdSlot";

const toolCategories = ["all", "Emulation", "Performance", "Streaming", "Utility", "Compatibility"];
const catLabels: Record<string, string> = {
  all: "All Tools", Emulation: "Emulation", Performance: "Performance",
  Streaming: "Streaming", Utility: "Utility", Compatibility: "Compatibility"
};

export default function ToolboxPage() {
  const [cat, setCat] = useState("all");
  const filtered = cat === "all" ? softwareTools : softwareTools.filter(t => t.category === cat);
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center py-12 mb-8">
        <Wrench className="w-12 h-12 text-emerald-400 mx-auto mb-4" />
        <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Gamer&apos;s Toolbox</h1>
        <p className="text-slate-400 max-w-2xl mx-auto">Essential software for handheld PC gaming — optimization, emulation, streaming, and productivity tools.</p>
      </div>

      {/* ─── INLINE 300x250 AD ─── */}
      <AdSlot type="banner-300" id="toolbox-inline-top" />

      <div className="flex flex-wrap gap-2 mb-8">
        {toolCategories.map(c => (
          <button key={c} onClick={() => setCat(c)} className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${cat === c ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}>
            {catLabels[c]} ({c === "all" ? softwareTools.length : softwareTools.filter(t => t.category === c).length})
          </button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {filtered.map(tool => (
          <div key={tool.name} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-emerald-500/40 transition-colors">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center">
                  <Settings className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">{tool.name}</h3>
                  <span className="text-xs text-slate-500 capitalize">{tool.category}</span>
                </div>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${tool.free ? "bg-emerald-500/10 text-emerald-400" : "bg-amber-500/10 text-amber-400"}`}>
                {tool.free ? "Free" : (tool as any).price || "Paid"}
              </span>
            </div>
            <p className="text-sm text-slate-400 mb-4">{tool.description}</p>
            <a href={tool.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 bg-violet-600 hover:bg-violet-500 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
              Get <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        ))}
      </div>

      {/* ─── NATIVE AD ─── */}
      <AdSlot type="native" id="toolbox-native-bottom" />
    </div>
  );
}
