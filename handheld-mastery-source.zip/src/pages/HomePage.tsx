import { ArrowRight, Star, BookOpen, Wrench, Scale, Gamepad2, Zap, HardDrive, Monitor, Gamepad } from "lucide-react";
import { products, softwareTools, categories, getBestPrice } from "@/data/products";
import AdSlot from "@/components/AdSlot";

const consoles = products.filter(p => p.category === "console").slice(0, 5);
const featuredTools = softwareTools.slice(0, 6);

const iconMap: Record<string, React.ElementType> = { Gamepad2, Zap, HardDrive, Monitor, Gamepad };

const featuredArticles = [
  { slug: "state-of-handheld-gaming-2026", title: "The State of Handheld Gaming in 2026", desc: "Why consoles are killing gaming laptops." },
  { slug: "steam-deck-oled-vs-rog-ally-x", title: "Steam Deck OLED vs. ROG Ally X", desc: "The heavyweight battle — $549 vs $999." },
  { slug: "how-to-install-emudeck", title: "How to Install EmuDeck", desc: "The easiest way to set up retro emulation." },
  { slug: "best-budget-handhelds-under-400", title: "Best Budget Handhelds Under $400", desc: "High performance for under $400." },
  { slug: "ultimate-windows-11-debloat-guide", title: "Ultimate Windows 11 Debloat Guide", desc: "Speed up your ROG Ally in 10 minutes." },
  { slug: "z2-extreme-vs-intel-core-ultra-200v", title: "Z2 Extreme vs. Intel Core Ultra 200V", desc: "The 2026 chip-set showdown." },
];

export default function HomePage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* ─── HERO ─── */}
      <div className="text-center py-16 sm:py-24">
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight mb-6">
          <span className="bg-gradient-to-r from-cyan-400 via-violet-400 to-fuchsia-400 bg-clip-text text-transparent">Hand Held</span><br />
          <span className="text-white">Mastery</span>
        </h1>
        <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto mb-8">The definitive technical resource for handheld gaming consoles, accessories, and optimization. 50+ products and 30 in-depth articles.</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a href="compare.html" className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold px-8 py-3 rounded-lg transition-colors">Compare Products <ArrowRight className="w-4 h-4" /></a>
          <a href="blog.html" className="inline-flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white font-semibold px-8 py-3 rounded-lg transition-colors border border-slate-700"><BookOpen className="w-4 h-4" /> Read 30 Articles</a>
        </div>
      </div>

      {/* ─── STATS ─── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
        {[{icon:Gamepad2,label:"Products",value:"50+",color:"text-cyan-400"},{icon:BookOpen,label:"Articles",value:"30",color:"text-violet-400"},{icon:Wrench,label:"Software Tools",value:"10+",color:"text-emerald-400"},{icon:Scale,label:"Retailer Networks",value:"5",color:"text-amber-400"}].map(s=>(<div key={s.label} className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-center"><s.icon className={`w-8 h-8 ${s.color} mx-auto mb-2`}/><div className="text-3xl font-bold text-white">{s.value}</div><div className="text-sm text-slate-400">{s.label}</div></div>))}
      </div>

      {/* ─── FEATURED CONSOLES ─── */}
      <h2 className="text-2xl font-bold text-white mb-6">Featured Consoles (2026)</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-16">
        {consoles.map(c=>(<a key={c.id} href="compare.html" className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-cyan-500/50 transition-colors group"><div className="text-xs font-medium text-cyan-400 uppercase tracking-wide mb-1">{c.subcategory}</div><h3 className="text-white font-semibold text-sm mb-2 group-hover:text-cyan-400 transition-colors">{c.name}</h3><div className="flex items-center gap-1 mb-2">{Array.from({length:5}).map((_,i)=>(<Star key={i} className={`w-3.5 h-3.5 ${i<Math.round(c.rating||0)?"text-amber-400 fill-amber-400":"text-slate-600"}`}/>))}<span className="text-xs text-slate-400 ml-1">{c.rating}</span></div><div className="text-lg font-bold text-white">${getBestPrice(c)}</div><div className="text-xs text-slate-500 mt-1 line-clamp-1">{c.bestFor}</div></a>))}
      </div>

      {/* ─── BROWSE BY CATEGORY ─── */}
      <h2 className="text-2xl font-bold text-white mb-6">Browse by Category</h2>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-16">
        {categories.map(cat=>{const Icon=iconMap[cat.icon]||Gamepad2;return(<a key={cat.id} href="compare.html" className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-center hover:border-violet-500/50 transition-colors group"><Icon className="w-8 h-8 text-violet-400 mx-auto mb-3 group-hover:scale-110 transition-transform"/><h3 className="text-white font-semibold">{cat.label}</h3><p className="text-sm text-slate-400 mt-1">{products.filter(p=>p.category===cat.id).length} products</p></a>)})}
      </div>

      {/* ─── LATEST ARTICLES ─── */}
      <h2 className="text-2xl font-bold text-white mb-6">Latest Articles</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {featuredArticles.map(a=>(<a key={a.slug} href={`./articles/${a.slug}.html`} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-cyan-500/40 transition-colors group"><h3 className="text-white font-semibold text-sm mb-2 group-hover:text-cyan-400 transition-colors">{a.title}</h3><p className="text-xs text-slate-400">{a.desc}</p><span className="text-xs text-cyan-400 mt-2 inline-flex items-center gap-1">Read article <ArrowRight className="w-3 h-3"/></span></a>))}
      </div>
      <div className="text-center mb-16"><a href="blog.html" className="text-cyan-400 hover:text-cyan-300 text-sm font-medium inline-flex items-center gap-1">View all 30 articles <ArrowRight className="w-4 h-4"/></a></div>

      {/* ─── GAMER'S TOOLBOX ─── */}
      <h2 className="text-2xl font-bold text-white mb-6">Gamer&apos;s Toolbox</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {featuredTools.map(t=>(<a key={t.name} href={t.url} target="_blank" rel="noopener noreferrer" className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-emerald-500/50 transition-colors"><div className="flex items-center justify-between mb-2"><h3 className="text-white font-semibold">{t.name}</h3><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${t.free?"bg-emerald-500/10 text-emerald-400":"bg-amber-500/10 text-amber-400"}`}>{t.free?"Free":(t as any).price||"Paid"}</span></div><p className="text-sm text-slate-400 line-clamp-2">{t.description}</p></a>))}
      </div>
      <div className="text-center mb-16"><a href="toolbox.html" className="text-cyan-400 hover:text-cyan-300 text-sm font-medium inline-flex items-center gap-1">View all tools <ArrowRight className="w-4 h-4"/></a></div>

      {/* ─── CTA ─── */}
      <div className="bg-gradient-to-r from-violet-900/20 to-cyan-900/20 border border-slate-800 rounded-2xl p-8 sm:p-12 text-center mb-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-white mb-3">Ready to master your handheld setup?</h2>
        <p className="text-slate-400 max-w-xl mx-auto mb-6">Compare all 50+ products side-by-side with real-time pricing, technical specs, and honest recommendations.</p>
        <a href="compare.html" className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold px-8 py-3 rounded-lg transition-colors">Start Comparing <ArrowRight className="w-4 h-4"/></a>
      </div>

      {/* ─── NATIVE AD ─── */}
      <AdSlot type="native" id="home-native-bottom" />
    </div>
  );
}
