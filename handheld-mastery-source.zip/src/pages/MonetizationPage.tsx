import { DollarSign, ShoppingCart, ExternalLink, TrendingUp, Tag, Gift } from "lucide-react";
import AdSlot from "@/components/AdSlot";

const networks = [
  { name: "Amazon Associates", desc: "World\'s largest affiliate program. 1-10% commission on gaming hardware, accessories, and games.", url: "https://affiliate-program.amazon.com", commission: "1-10%", cookie: "24 hours" },
  { name: "ShareASale", desc: "Major affiliate network with gaming retailers like Razer, Corsair, and SteelSeries.", url: "https://www.shareasale.com", commission: "5-20%", cookie: "30-90 days" },
  { name: "CJ Affiliate", desc: "Enterprise-grade network with Best Buy, Walmart, and major gaming brands.", url: "https://www.cj.com", commission: "3-15%", cookie: "7-45 days" },
  { name: "Rakuten Advertising", desc: "Strong international coverage. Good for UK/EU gaming retailers.", url: "https://rakutenadvertising.com", commission: "3-12%", cookie: "30 days" },
  { name: "Newegg Affiliate", desc: "Tech-focused retailer with competitive commissions on PC components and gaming gear.", url: "https://www.newegg.com/affiliate", commission: "1-5%", cookie: "7 days" },
];

const priceTools = [
  { name: "Keepa", desc: "Amazon price history tracker. Essential for showing deal trends.", url: "https://keepa.com" },
  { name: "CamelCamelCamel", desc: "Free Amazon price tracker with alerts.", url: "https://camelcamelcamel.com" },
  { name: "PriceRunner", desc: "Multi-retailer price comparison for EU markets.", url: "https://www.pricerunner.com" },
  { name: "Honey", desc: "Automatic coupon finder — good for reader recommendations.", url: "https://www.joinhoney.com" },
];

const tips = [
  { icon: Tag, title: "Deep Linking", desc: "Link directly to product pages, not homepages. Conversion rates are 3-5x higher." },
  { icon: TrendingUp, title: "Seasonal Content", desc: "Black Friday, Prime Day, and back-to-school drive 40-60% of annual affiliate revenue." },
  { icon: Gift, title: "Deal Roundups", desc: "Weekly deal posts with 8-12 products consistently outperform single-product reviews." },
  { icon: DollarSign, title: "High-Ticket Items", desc: "A single $1000 console sale at 4% = $40. Focus on premium products for maximum revenue." },
];

export default function MonetizationPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="text-center py-12 mb-8">
        <DollarSign className="w-12 h-12 text-amber-400 mx-auto mb-4" />
        <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Affiliate Hub</h1>
        <p className="text-slate-400 max-w-2xl mx-auto">Monetization resources, affiliate networks, and price comparison tools for Hand Held Mastery.</p>
      </div>

      {/* ─── INLINE 300x250 AD ─── */}
      <AdSlot type="banner-300" id="monetization-inline-top" />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
        <div>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><ShoppingCart className="w-6 h-6 text-violet-400" /> Affiliate Networks</h2>
          <div className="space-y-4">
            {networks.map(n => (
              <div key={n.name} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-amber-500/40 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-semibold">{n.name}</h3>
                  <span className="text-xs bg-amber-500/10 text-amber-400 px-2 py-0.5 rounded-full font-medium">{n.commission}</span>
                </div>
                <p className="text-sm text-slate-400 mb-3">{n.desc}</p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-500">Cookie: {n.cookie}</span>
                  <a href={n.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 text-sm font-medium">Join <ExternalLink className="w-3.5 h-3.5" /></a>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><TrendingUp className="w-6 h-6 text-emerald-400" /> Price Comparison Tools</h2>
          <div className="space-y-4 mb-8">
            {priceTools.map(t => (
              <div key={t.name} className="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-emerald-500/40 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-white font-semibold">{t.name}</h3>
                  <span className="text-xs bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full font-medium">Free</span>
                </div>
                <p className="text-sm text-slate-400 mb-3">{t.desc}</p>
                <a href={t.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-cyan-400 hover:text-cyan-300 text-sm font-medium">Visit <ExternalLink className="w-3.5 h-3.5" /></a>
              </div>
            ))}
          </div>
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2"><DollarSign className="w-6 h-6 text-cyan-400" /> Revenue Tips</h2>
          <div className="space-y-4">
            {tips.map(t => (
              <div key={t.title} className="bg-slate-900 border border-slate-800 rounded-xl p-5">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center"><t.icon className="w-4 h-4 text-cyan-400" /></div>
                  <h3 className="text-white font-semibold">{t.title}</h3>
                </div>
                <p className="text-sm text-slate-400">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ─── NATIVE AD ─── */}
      <AdSlot type="native" id="monetization-native-bottom" />
    </div>
  );
}
