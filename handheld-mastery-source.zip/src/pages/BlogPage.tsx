import { useState, useMemo } from "react";
import { Search, BookOpen, Wrench, Scale, ArrowRight, Calendar, Clock, Tag } from "lucide-react";
import { articles } from "@/data/articles";
import AdSlot from "@/components/AdSlot";

type CatFilter = "all" | "blog" | "howto" | "versus";

const catConfig: Record<string, { label: string; icon: any; color: string; hover: string; bg: string }> = {
  all:   { label: "All Articles", icon: BookOpen, color: "text-white", hover: "hover:border-cyan-500/40", bg: "bg-slate-800" },
  blog:  { label: "Blog", icon: BookOpen, color: "text-cyan-400", hover: "hover:border-cyan-500/40", bg: "bg-cyan-500/10" },
  howto: { label: "How-To", icon: Wrench, color: "text-emerald-400", hover: "hover:border-emerald-500/40", bg: "bg-emerald-500/10" },
  versus:{ label: "Versus", icon: Scale, color: "text-violet-400", hover: "hover:border-violet-500/40", bg: "bg-violet-500/10" },
};

export default function BlogPage() {
  const [cat, setCat] = useState<CatFilter>("all");
  const [search, setSearch] = useState("");
  const filtered = useMemo(() => {
    let list = cat === "all" ? articles : articles.filter(a => a.category === cat);
    if (search.trim()) { const q = search.toLowerCase(); list = list.filter(a => a.title.toLowerCase().includes(q) || a.description.toLowerCase().includes(q) || a.tags.some(t => t.toLowerCase().includes(q))); }
    return list;
  }, [cat, search]);
  const featured = articles.slice(0, 3);
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* ─── HERO ─── */}
      <div className="text-center py-12 mb-8">
        <BookOpen className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
        <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3">Hand Held Mastery Blog</h1>
        <p className="text-slate-400 max-w-2xl mx-auto">{articles.length} in-depth articles covering reviews, how-to guides, and head-to-head comparisons.</p>
      </div>

      {/* ─── 728x90 LEADERBOARD ─── */}
      <AdSlot type="banner-728" id="leaderboard-blog-top" />

      {/* ─── FEATURED ARTICLES ─── */}
      <div className="mb-8">
        <h2 className="text-xl font-bold text-white mb-4">Featured Articles</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {featured.map(a => {
            const cfg = catConfig[a.category];
            const Icon = cfg.icon;
            return (
              <a key={a.slug} href={`./articles/${a.slug}.html`} className={`bg-slate-900 border border-slate-800 rounded-xl p-5 ${cfg.hover} transition-colors group`}>
                <div className="flex items-center gap-2 mb-3"><span className={`text-xs ${cfg.bg} ${cfg.color} px-2 py-0.5 rounded-full font-medium flex items-center gap-1`}><Icon className="w-3 h-3" />{a.categoryLabel}</span></div>
                <h3 className="text-white font-semibold text-sm mb-2 group-hover:text-cyan-400 transition-colors line-clamp-2">{a.title}</h3>
                <p className="text-xs text-slate-400 line-clamp-2 mb-3">{a.description}</p>
                <div className="flex items-center gap-3 text-xs text-slate-500"><span className="flex items-center gap-1"><Calendar className="w-3 h-3"/>{a.publishDate}</span><span className="flex items-center gap-1"><Clock className="w-3 h-3"/>{a.readTime}</span></div>
              </a>
            );
          })}
        </div>
      </div>

      {/* ─── INLINE 300x250 AD ─── */}
      <AdSlot type="banner-300" id="blog-inline-mid" />

      {/* ─── SEARCH & FILTERS ─── */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input type="text" placeholder="Search articles by title, tag, or topic..." value={search} onChange={e => setSearch(e.target.value)} className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-10 pr-4 py-2.5 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500 text-sm" />
        </div>
        <div className="flex gap-2">
          {(["all","blog","howto","versus"] as CatFilter[]).map(c => {
            const cfg = catConfig[c];
            const Icon = cfg.icon;
            return (
              <button key={c} onClick={() => setCat(c)} className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${cat === c ? "bg-violet-600 text-white" : "bg-slate-800 text-slate-300 hover:bg-slate-700"}`}>
                <Icon className="w-4 h-4" /> {cfg.label.split(" ")[0]} ({c === "all" ? articles.length : articles.filter(a => a.category === c).length})
              </button>
            );
          })}
        </div>
      </div>

      {/* ─── ARTICLE GRID ─── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {filtered.map(a => {
          const cfg = catConfig[a.category];
          const Icon = cfg.icon;
          return (
            <a key={a.slug} href={`./articles/${a.slug}.html`} className={`bg-slate-900 border border-slate-800 rounded-xl p-5 ${cfg.hover} transition-colors group flex flex-col`}>
              <div className="flex items-center gap-2 mb-3"><span className={`text-xs ${cfg.bg} ${cfg.color} px-2 py-0.5 rounded-full font-medium flex items-center gap-1`}><Icon className="w-3 h-3" />{a.categoryLabel}</span></div>
              <h3 className="text-white font-semibold text-sm mb-2 group-hover:text-cyan-400 transition-colors flex-1 line-clamp-2">{a.title}</h3>
              <p className="text-xs text-slate-400 line-clamp-2 mb-3">{a.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs text-slate-500">
                  <span className="flex items-center gap-1"><Calendar className="w-3 h-3"/>{a.publishDate}</span>
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3"/>{a.readTime}</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mt-3">
                {a.tags.slice(0, 3).map(t => <span key={t} className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded flex items-center gap-0.5"><Tag className="w-2.5 h-2.5"/>{t}</span>)}
              </div>
            </a>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-16"><Search className="w-12 h-12 text-slate-600 mx-auto mb-4" /><p className="text-slate-400">No articles match your search.</p><button onClick={() => { setCat("all"); setSearch(""); }} className="text-cyan-400 hover:text-cyan-300 text-sm mt-2">Clear filters</button></div>
      )}

      {/* ─── NATIVE AD ─── */}
      <AdSlot type="native" id="blog-native-bottom" />
    </div>
  );
}
