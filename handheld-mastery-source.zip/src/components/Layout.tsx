import Navbar from "./Navbar";
import Footer from "./Footer";
import AdSlot from "./AdSlot";

interface LayoutProps { children: React.ReactNode; active?: string; }

export default function Layout({ children, active }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <AdSlot type="popunder" id="popunder-site-wide" />
      <Navbar active={active} />
      <div className="bg-slate-900/50 border-b border-slate-800"><AdSlot type="banner-728" id="leaderboard-top-all" /></div>
      <main className="flex-1">{children}</main>
      <div className="bg-slate-900/50 border-t border-slate-800"><AdSlot type="banner-728" id="leaderboard-bottom-all" /></div>
      <Footer />
      <AdSlot type="social-bar" id="social-bar-sticky" />
    </div>
  );
}
