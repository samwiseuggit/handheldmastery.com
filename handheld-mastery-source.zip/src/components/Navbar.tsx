import { useState } from "react";
import { Menu, X } from "lucide-react";

interface NavbarProps { active?: string; }

const navLinks = [
  { href: "index.html", label: "Home", id: "home" },
  { href: "compare.html", label: "Compare", id: "compare" },
  { href: "blog.html", label: "Blog", id: "blog" },
  { href: "toolbox.html", label: "Toolbox", id: "toolbox" },
  { href: "monetization.html", label: "Monetization", id: "monetization" },
  { href: "sitemap.html", label: "Sitemap", id: "sitemap" },
];

export default function Navbar({ active }: NavbarProps) {
  const [open, setOpen] = useState(false);
  return (
    <nav className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-2 sm:px-3 lg:px-4">
        <div className="flex items-center justify-between h-20 sm:h-24">
          <a href="index.html" className="flex items-center shrink-0 -ml-1">
            <img src="./logo.png" alt="Hand Held Mastery" className="h-16 sm:h-20 w-auto object-contain" loading="eager" />
          </a>
          <div className="hidden md:flex items-center gap-0.5">
            {navLinks.map(link => (
              <a key={link.id} href={link.href} className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${active === link.id ? "bg-cyan-500/10 text-cyan-400" : "text-slate-300 hover:text-white hover:bg-slate-800"}`}>{link.label}</a>
            ))}
          </div>
          <button onClick={() => setOpen(!open)} className="md:hidden text-slate-300 hover:text-white p-2">{open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}</button>
        </div>
        {open && (
          <div className="md:hidden pb-3 space-y-0.5">
            {navLinks.map(link => (
              <a key={link.id} href={link.href} onClick={() => setOpen(false)} className={`block px-4 py-3 rounded-md text-sm font-medium ${active === link.id ? "bg-cyan-500/10 text-cyan-400" : "text-slate-300 hover:text-white hover:bg-slate-800"}`}>{link.label}</a>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
