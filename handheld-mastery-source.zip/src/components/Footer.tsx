export default function Footer() {
  return (
    <footer className="bg-slate-900 border-t border-slate-800 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <img src="./logo.png" alt="Hand Held Mastery" className="h-8 w-auto mb-3" />
            <p className="text-slate-400 text-sm">The definitive technical resource for handheld PC gaming consoles, accessories, and optimization guides. Master your handheld setup.</p>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-3">Quick Links</h3>
            <div className="space-y-2">
              {["index.html","compare.html","blog.html","toolbox.html","monetization.html","sitemap.html"].map((href, i) => (
                <a key={href} href={href} className="block text-slate-400 hover:text-cyan-400 text-sm">{["Home","Compare Products","Blog","Gamer\'s Toolbox","Affiliate Hub","Sitemap"][i]}</a>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-white font-semibold mb-3">Disclosure</h3>
            <p className="text-slate-400 text-sm">This site contains affiliate links. We may earn a commission when you purchase through our links — at no extra cost to you. All reviews are independent and unsponsored.</p>
          </div>
        </div>
        <div className="border-t border-slate-800 mt-8 pt-6 text-center text-slate-500 text-sm">&copy; 2026 Hand Held Mastery. All rights reserved.</div>
      </div>
    </footer>
  );
}
