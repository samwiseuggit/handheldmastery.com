import { useEffect, useRef } from "react";

interface AdSlotProps {
  type: "popunder" | "banner-728" | "banner-300" | "native" | "social-bar";
  id?: string;
  className?: string;
}

export default function AdSlot({ type, id, className }: AdSlotProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const injectedRef = useRef(false);

  useEffect(() => {
    if (!containerRef.current || injectedRef.current) return;
    const el = containerRef.current;
    const flagKey = `__adInjected_${type}_${id || "default"}`;
    if ((el as any).__adInjected || (window as any)[flagKey]) return;
    (el as any).__adInjected = true;
    (window as any)[flagKey] = true;
    injectedRef.current = true;

    if (type === "popunder") {
      const s = document.createElement("script");
      s.src = "https://pl29763343.effectivecpmnetwork.com/fa/c5/2e/fac52e793a9842c90f533b5380ed1dbc.js";
      el.appendChild(s);
    } else if (type === "banner-728") {
      const opts = document.createElement("script");
      opts.text = `atOptions = { key: \'4428d04f24f7240a987e9ddf4e0c117c\', format: \'iframe\', height: 90, width: 728, params: {} };`;
      el.appendChild(opts);
      const s = document.createElement("script");
      s.src = "https://www.highperformanceformat.com/4428d04f24f7240a987e9ddf4e0c117c/invoke.js";
      el.appendChild(s);
    } else if (type === "banner-300") {
      const opts = document.createElement("script");
      opts.text = `atOptions = { key: \'5a80ce7f116946c73b77837f2eb661f6\', format: \'iframe\', height: 250, width: 300, params: {} };`;
      el.appendChild(opts);
      const s = document.createElement("script");
      s.src = "https://www.highperformanceformat.com/5a80ce7f116946c73b77837f2eb661f6/invoke.js";
      el.appendChild(s);
    } else if (type === "native") {
      const s = document.createElement("script");
      s.src = "https://pl29763344.effectivecpmnetwork.com/8b7696e02f356d6562fb7d33ae23ef75/invoke.js";
      s.async = true;
      s.setAttribute("data-cfasync", "false");
      el.appendChild(s);
      const div = document.createElement("div");
      div.id = "container-8b7696e02f356d6562fb7d33ae23ef75";
      el.appendChild(div);
    } else if (type === "social-bar") {
      const s = document.createElement("script");
      s.src = "https://pl29763345.effectivecpmnetwork.com/ca/52/26/ca5226567c13e5d31689b0c86207ae74.js";
      el.appendChild(s);
    }
  }, [type, id]);

  if (type === "popunder") {
    return <div ref={containerRef} id={id} style={{ display: "none" }} aria-hidden="true" />;
  }
  if (type === "social-bar") {
    return <div ref={containerRef} id={id} className={`fixed bottom-0 left-0 right-0 z-40 ${className || ""}`} />;
  }
  if (type === "native") {
    return <div ref={containerRef} id={id} className={`my-4 ${className || ""}`} />;
  }
  const dims = type === "banner-728" ? "w-[728px] h-[90px] mx-auto my-2 hidden md:block" : "w-[300px] h-[250px] mx-auto my-4";
  return <div ref={containerRef} id={id} className={`${dims} ${className || ""}`} />;
}
