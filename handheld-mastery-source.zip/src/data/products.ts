// 50-Product Modern Comparison Database for Handheld PC Gaming KB
// Updated: May 2026

export interface Product {
  id: string;
  name: string;
  category: 'console' | 'power' | 'storage' | 'dock' | 'peripheral';
  subcategory: string;
  retailerLinks: { amazon?: string; bestbuy?: string; walmart?: string; jsaux?: string; direct?: string };
  price: { amazon?: number; bestbuy?: number; walmart?: number; jsaux?: number; direct?: number; msrp: number };
  keySpecs: Record<string, string>;
  bestFor: string;
  rating?: number;
  image?: string;
}

export const products: Product[] = [
  // === CONSOLES (10) ===
  {
    id: 'deck-oled-512',
    name: 'Steam Deck OLED (512GB)',
    category: 'console',
    subcategory: 'OLED Handheld',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0CV7BJH7R', bestbuy: 'https://bestbuy.com/steam-deck-oled', walmart: 'https://walmart.com/steam-deck-oled', direct: 'https://store.steampowered.com/steamdeck' },
    price: { amazon: 549, bestbuy: 549, walmart: 549, msrp: 549 },
    keySpecs: { display: '7.4" HDR OLED 1280×800 90Hz', cpu: 'AMD Aerith APU (Zen 2, 7nm)', gpu: '8 RDNA 2 CUs', ram: '16GB LPDDR5-5500', storage: '512GB NVMe SSD', battery: '50Wh', weight: '640g', os: 'SteamOS 3.0', tdp: '4-15W' },
    bestFor: 'Best value, best ergonomics, console-like simplicity', rating: 4.6
  },
  {
    id: 'deck-oled-1tb',
    name: 'Steam Deck OLED (1TB)',
    category: 'console',
    subcategory: 'OLED Handheld',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0CV7CKZ9Y', bestbuy: 'https://bestbuy.com/steam-deck-oled-1tb', walmart: 'https://walmart.com/steam-deck-oled-1tb', direct: 'https://store.steampowered.com/steamdeck' },
    price: { amazon: 649, bestbuy: 649, walmart: 649, msrp: 649 },
    keySpecs: { display: '7.4" HDR OLED 1280×800 90Hz', cpu: 'AMD Aerith APU', gpu: '8 RDNA 2 CUs', ram: '16GB LPDDR5-5500', storage: '1TB NVMe SSD', battery: '50Wh', weight: '640g', os: 'SteamOS 3.0', tdp: '4-15W' },
    bestFor: 'Best value with room for large libraries', rating: 4.7
  },
  {
    id: 'rog-ally-x',
    name: 'ASUS ROG Xbox Ally X',
    category: 'console',
    subcategory: 'Flagship Windows',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0DKLHHMZ7', bestbuy: 'https://bestbuy.com/rog-ally-x', walmart: 'https://walmart.com/rog-ally-x', direct: 'https://asus.com/rog-ally-x' },
    price: { amazon: 999, bestbuy: 999, walmart: 999, msrp: 999 },
    keySpecs: { display: '7" FHD IPS 1920×1080 120Hz VRR', cpu: 'AMD Z2 Extreme (Zen 5)', gpu: '16 RDNA 3.5 CUs', ram: '24GB LPDDR5X-8000', storage: '1TB NVMe SSD', battery: '80Wh', weight: '715g', os: 'Windows 11 (Xbox UI)', tdp: '9-35W' },
    bestFor: 'Best Windows performance, Xbox ecosystem, premium gaming', rating: 4.5
  },
  {
    id: 'legion-go-2-oled',
    name: 'Lenovo Legion Go 2 (OLED)',
    category: 'console',
    subcategory: 'Big Screen Premium',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0DKP9ZBCQ', bestbuy: 'https://bestbuy.com/legion-go-2', walmart: 'https://walmart.com/legion-go-2', direct: 'https://lenovo.com/legion-go-2' },
    price: { amazon: 1349, bestbuy: 1349, walmart: 1349, msrp: 1349 },
    keySpecs: { display: '8.8" OLED 2560×1600 144Hz VRR', cpu: 'AMD Z2 Extreme', gpu: '16 RDNA 3.5 CUs', ram: '32GB LPDDR5X-8000', storage: '1TB NVMe SSD', battery: '74Wh', weight: '920g', os: 'Windows 11 / SteamOS', tdp: '9-35W' },
    bestFor: 'Biggest OLED screen, detachable controllers, kickstand', rating: 4.3
  },
  {
    id: 'legion-go-s',
    name: 'Lenovo Legion Go S (SteamOS)',
    category: 'console',
    subcategory: 'SteamOS Alternative',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0DKP9XYZ', bestbuy: 'https://bestbuy.com/legion-go-s', walmart: 'https://walmart.com/legion-go-s', direct: 'https://lenovo.com/legion-go-s' },
    price: { amazon: 650, bestbuy: 650, walmart: 650, msrp: 650 },
    keySpecs: { display: '7" IPS 1920×1080 120Hz VRR', cpu: 'AMD Z2 Go', gpu: '12 RDNA 3.5 CUs', ram: '16GB LPDDR5X-6400', storage: '512GB NVMe SSD', battery: '55.5Wh', weight: '720g', os: 'SteamOS', tdp: '9-25W' },
    bestFor: 'SteamOS with bigger screen than Deck, better performance', rating: 4.4
  },
  {
    id: 'msi-claw-8-ai',
    name: 'MSI Claw 8 AI+',
    category: 'console',
    subcategory: 'Intel Handheld',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0DKKMV3NS', bestbuy: 'https://bestbuy.com/msi-claw-8', walmart: 'https://walmart.com/msi-claw-8', direct: 'https://msi.com/claw-8-ai' },
    price: { amazon: 1085, bestbuy: 1099, walmart: 1049, msrp: 899 },
    keySpecs: { display: '8" IPS 1920×1200 120Hz VRR', cpu: 'Intel Core Ultra 7 258V', gpu: 'Intel Arc 140V (Xe2)', ram: '32GB LPDDR5x-8533', storage: '1TB PCIe Gen4 SSD', battery: '80Wh', weight: '795g', os: 'Windows 11', tdp: '10-30W' },
    bestFor: 'Best battery life, Hall Effect sticks, Thunderbolt 4', rating: 4.2
  },
  {
    id: 'gpd-win-5',
    name: 'GPD Win 5',
    category: 'console',
    subcategory: 'Enthusiast',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0DKP12345', direct: 'https://gpd.hk/win-5' },
    price: { amazon: 1399, direct: 1399, msrp: 1399 },
    keySpecs: { display: '6" OLED 2560×1440 120Hz', cpu: 'AMD Z2 Extreme', gpu: '16 RDNA 3.5 CUs', ram: '32GB LPDDR5X-8000', storage: '2TB NVMe SSD', battery: '60Wh', weight: '580g', os: 'Windows 11', tdp: '9-35W' },
    bestFor: 'Smallest Z2 Extreme, slide-out keyboard, 2TB storage', rating: 4.0
  },
  {
    id: 'onexplayer-x1-air',
    name: 'OneXPlayer X1 Air',
    category: 'console',
    subcategory: 'Enthusiast',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0DKP67890', direct: 'https://onexplayer.com/x1-air' },
    price: { amazon: 1299, direct: 1299, msrp: 1299 },
    keySpecs: { display: '10.95" 2.5K 120Hz', cpu: 'AMD Z2 Extreme', gpu: '16 RDNA 3.5 CUs', ram: '64GB LPDDR5X', storage: '2TB NVMe SSD', battery: '65Wh', weight: '980g', os: 'Windows 11', tdp: '9-35W' },
    bestFor: 'Largest screen, 64GB RAM, productivity+gaming hybrid', rating: 3.9
  },
  {
    id: 'onexfly-apex',
    name: 'OneXFly Apex',
    category: 'console',
    subcategory: 'Enthusiast',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0DKPABCDE', direct: 'https://onexplayer.com/onexfly-apex' },
    price: { amazon: 1199, direct: 1199, msrp: 1199 },
    keySpecs: { display: '7" FHD 144Hz', cpu: 'AMD Z2 Extreme', gpu: '16 RDNA 3.5 CUs', ram: '32GB LPDDR5X', storage: '1TB NVMe SSD', battery: '65Wh', weight: '620g', os: 'Windows 11', tdp: '9-35W' },
    bestFor: 'Compact performance, 144Hz display, lightweight', rating: 4.0
  },
  {
    id: 'deck-oled-refurb',
    name: 'Steam Deck OLED 512GB (Refurbished)',
    category: 'console',
    subcategory: 'Budget',
    retailerLinks: { direct: 'https://store.steampowered.com/steamdeck' },
    price: { direct: 439, msrp: 439 },
    keySpecs: { display: '7.4" HDR OLED 1280×800 90Hz', cpu: 'AMD Aerith APU', gpu: '8 RDNA 2 CUs', ram: '16GB LPDDR5-5500', storage: '512GB NVMe SSD', battery: '50Wh', weight: '640g', os: 'SteamOS 3.0', tdp: '4-15W', warranty: '1-year Valve warranty' },
    bestFor: 'Best entry point, full warranty, identical performance', rating: 4.8
  },

  // === POWER SOLUTIONS (10) ===
  {
    id: 'anker-737',
    name: 'Anker 737 PowerCore 24K (140W)',
    category: 'power',
    subcategory: 'Power Bank',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BW4JH8FC', bestbuy: 'https://bestbuy.com/anker-737', jsaux: '' },
    price: { amazon: 109, bestbuy: 129, msrp: 149 },
    keySpecs: { capacity: '24,000mAh (89Wh)', maxOutput: '140W PD 3.1', ports: '2× USB-C + 1× USB-A', weight: '640g', display: 'TFT smart display', flights: 'Airline approved (≤100Wh)' },
    bestFor: 'Premium build, fastest charging, digital display', rating: 4.7
  },
  {
    id: 'baseus-blade-100w',
    name: 'Baseus Blade 100W',
    category: 'power',
    subcategory: 'Power Bank',
    retailerLinks: { amazon: 'https://amazon.com/dp/B09P5CKR5K', bestbuy: '', walmart: '' },
    price: { amazon: 49, msrp: 69 },
    keySpecs: { capacity: '20,000mAh (74Wh)', maxOutput: '100W PD 3.0', ports: '2× USB-C + 2× USB-A', weight: '490g', thickness: '0.7"', flights: 'Airline approved' },
    bestFor: 'Best value, slim design, great for travel', rating: 4.5
  },
  {
    id: 'iniu-100w-25k',
    name: 'INIU 100W 25,000mAh',
    category: 'power',
    subcategory: 'Power Bank',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C6BJL7KW', walmart: '' },
    price: { amazon: 27, walmart: 32, msrp: 49 },
    keySpecs: { capacity: '25,000mAh (92.5Wh)', maxOutput: '100W PD 3.0', ports: '2× USB-C + 1× USB-A', weight: '480g', flights: 'Check airline (92.5Wh)' },
    bestFor: 'Best budget, massive capacity', rating: 4.3
  },
  {
    id: 'shargeek-storm-2',
    name: 'Shargeek Storm 2',
    category: 'power',
    subcategory: 'Power Bank',
    retailerLinks: { amazon: 'https://amazon.com/dp/B09WJZDLJ2', direct: 'https://shargeek.com/storm-2' },
    price: { amazon: 199, direct: 199, msrp: 229 },
    keySpecs: { capacity: '25,600mAh (93.5Wh)', maxOutput: '100W PD 3.0', ports: '1× USB-C + 1× DC + 1× USB-A', weight: '580g', display: 'IPS screen with real-time stats', flights: 'Check airline' },
    bestFor: 'Enthusiast features, visible circuitry, DC output', rating: 4.4
  },
  {
    id: 'zendure-supertank',
    name: 'Zendure SuperTank',
    category: 'power',
    subcategory: 'Power Bank',
    retailerLinks: { amazon: 'https://amazon.com/dp/B07XCX7P2X', direct: 'https://zendure.com/supertank' },
    price: { amazon: 129, direct: 129, msrp: 149 },
    keySpecs: { capacity: '27,000mAh (100Wh)', maxOutput: '100W PD', ports: '2× USB-C + 2× USB-A', weight: '500g', flights: 'Maximum allowed (100Wh)' },
    bestFor: 'Maximum flight-legal capacity, pass-through charging', rating: 4.2
  },
  {
    id: 'anker-nano-ii-65w',
    name: 'Anker Nano II 65W (GaN II)',
    category: 'power',
    subcategory: 'Wall Charger',
    retailerLinks: { amazon: 'https://amazon.com/dp/B09C5RG6LV', bestbuy: '', walmart: '' },
    price: { amazon: 29, msrp: 39 },
    keySpecs: { type: 'GaN II Wall Charger', maxOutput: '65W PD 3.0', ports: '1× USB-C', size: 'AirPods Pro size', weight: '110g', prongs: 'Foldable' },
    bestFor: 'Ultra-compact travel charger, reliable brand', rating: 4.6
  },
  {
    id: 'ugreen-nexode-100w',
    name: 'UGREEN Nexode 100W (GaN)',
    category: 'power',
    subcategory: 'Wall Charger',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B129DMQR', bestbuy: '' },
    price: { amazon: 33, msrp: 55 },
    keySpecs: { type: 'GaN Wall Charger', maxOutput: '100W PD 3.0', ports: '3× USB-C + 1× USB-A', size: 'Compact cube', weight: '215g', prongs: 'Foldable' },
    bestFor: 'Multi-device charging, best value 100W', rating: 4.5
  },
  {
    id: 'ugreen-nexode-140w',
    name: 'UGREEN Nexode 140W (GaN)',
    category: 'power',
    subcategory: 'Wall Charger',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B1CJ4QGH', bestbuy: '' },
    price: { amazon: 59, msrp: 79 },
    keySpecs: { type: 'GaN Wall Charger', maxOutput: '140W PD 3.1', ports: '2× USB-C + 1× USB-A', size: 'Compact', weight: '260g', prongs: 'Foldable' },
    bestFor: 'Future-proof 140W for ROG Ally X at full TDP', rating: 4.4
  },
  {
    id: 'baseus-65w-gan',
    name: 'Baseus 65W GaN3 Pro',
    category: 'power',
    subcategory: 'Wall Charger',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B5VJV4FC', walmart: '' },
    price: { amazon: 25, msrp: 35 },
    keySpecs: { type: 'GaN3 Wall Charger', maxOutput: '65W PD 3.0', ports: '2× USB-C + 1× USB-A', size: 'Compact', weight: '130g', prongs: 'Foldable' },
    bestFor: 'Best budget GaN charger, multi-port', rating: 4.3
  },
  {
    id: 'jsaux-100w-cable',
    name: 'JSAUX 100W Right-Angle USB-C Cable',
    category: 'power',
    subcategory: 'Cable',
    retailerLinks: { amazon: 'https://amazon.com/dp/B09Q7J7FKL', jsaux: 'https://jsaux.com/cables' },
    price: { amazon: 10, jsaux: 10, msrp: 14 },
    keySpecs: { maxPower: '100W PD 3.0', length: '6.6ft / 2m', connector: 'Right-angle USB-C', data: 'USB 2.0 (480Mbps)', braided: 'Nylon braided' },
    bestFor: 'Prevents port stress, essential for handheld gaming', rating: 4.6
  },

  // === STORAGE (10) ===
  {
    id: 'corsair-mp600-mini',
    name: 'Corsair MP600 Mini (E27T) 1TB',
    category: 'storage',
    subcategory: 'M.2 2230 SSD',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BYJ6G71B', bestbuy: '' },
    price: { amazon: 149, msrp: 159 },
    keySpecs: { formFactor: 'M.2 2230', interface: 'PCIe Gen4 x4', readSpeed: '7,000 MB/s', writeSpeed: '6,500 MB/s', nand: '3D TLC', endurance: '600 TBW', controller: 'Phison E27T' },
    bestFor: 'Fastest 2230 SSD, premium build', rating: 4.7
  },
  {
    id: 'samsung-pm9b1-1tb',
    name: 'Samsung PM9B1 1TB (OEM)',
    category: 'storage',
    subcategory: 'M.2 2230 SSD',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B4VMT4VZ', walmart: '' },
    price: { amazon: 85, walmart: 90, msrp: 99 },
    keySpecs: { formFactor: 'M.2 2230', interface: 'PCIe Gen4 x4', readSpeed: '3,600 MB/s', writeSpeed: '3,000 MB/s', nand: '3D TLC', endurance: '300 TBW', controller: 'Samsung in-house' },
    bestFor: 'Best budget OEM SSD, reliable Samsung NAND', rating: 4.4
  },
  {
    id: 'wd-sn740-1tb',
    name: 'WD Black SN740 1TB (2230)',
    category: 'storage',
    subcategory: 'M.2 2230 SSD',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BYJP7Y3R', bestbuy: '' },
    price: { amazon: 99, msrp: 119 },
    keySpecs: { formFactor: 'M.2 2230', interface: 'PCIe Gen4 x4', readSpeed: '5,150 MB/s', writeSpeed: '4,900 MB/s', nand: '3D TLC', endurance: '400 TBW', controller: 'WD in-house' },
    bestFor: 'Best mid-range speed/price balance', rating: 4.5
  },
  {
    id: 'sabrent-rocket-2230',
    name: 'Sabrent Rocket 2230 1TB',
    category: 'storage',
    subcategory: 'M.2 2230 SSD',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BQGQTW8B', bestbuy: '' },
    price: { amazon: 119, msrp: 129 },
    keySpecs: { formFactor: 'M.2 2230', interface: 'PCIe Gen4 x4', readSpeed: '4,750 MB/s', writeSpeed: '4,300 MB/s', nand: '3D TLC', endurance: '600 TBW', controller: 'Phison E21T' },
    bestFor: 'Good endurance, trusted brand', rating: 4.3
  },
  {
    id: 'foresee-xp2000',
    name: 'Foresee XP2000 1TB (2230)',
    category: 'storage',
    subcategory: 'M.2 2230 SSD',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C1234567', walmart: '' },
    price: { amazon: 75, walmart: 78, msrp: 89 },
    keySpecs: { formFactor: 'M.2 2230', interface: 'PCIe Gen3 x4', readSpeed: '2,100 MB/s', writeSpeed: '1,700 MB/s', nand: '3D TLC', endurance: '300 TBW', controller: 'SM2263XT' },
    bestFor: 'Cheapest 1TB 2230, PCIe Gen3 sufficient for Deck', rating: 4.0
  },
  {
    id: 'samsung-pro-ultimate-512',
    name: 'Samsung PRO Ultimate 512GB microSD',
    category: 'storage',
    subcategory: 'microSD Card',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BZP5Q7B8', bestbuy: '', walmart: '' },
    price: { amazon: 65, msrp: 79 },
    keySpecs: { capacity: '512GB', readSpeed: '200 MB/s', writeSpeed: '130 MB/s', rating: 'U3, V30, A2, UHS-I', warranty: '10-year limited' },
    bestFor: 'Fastest microSD for handhelds, 10-year warranty', rating: 4.6
  },
  {
    id: 'sandisk-extreme-pro-512',
    name: 'SanDisk Extreme PRO 512GB microSD',
    category: 'storage',
    subcategory: 'microSD Card',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BTX8FN1B', bestbuy: '', walmart: '' },
    price: { amazon: 58, msrp: 69 },
    keySpecs: { capacity: '512GB', readSpeed: '200 MB/s', writeSpeed: '140 MB/s', rating: 'U3, V30, A2, UHS-I', warranty: 'Lifetime limited' },
    bestFor: 'Best write speeds, lifetime warranty', rating: 4.5
  },
  {
    id: 'lexar-silver-plus-1tb',
    name: 'Lexar Professional Silver Plus 1TB microSD',
    category: 'storage',
    subcategory: 'microSD Card',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C2P12345', bestbuy: '' },
    price: { amazon: 89, msrp: 99 },
    keySpecs: { capacity: '1TB', readSpeed: '205 MB/s', writeSpeed: '140 MB/s', rating: 'U3, V30, A2, UHS-I', warranty: 'Lifetime limited' },
    bestFor: 'Best value 1TB card, good speeds', rating: 4.4
  },
  {
    id: 'kingston-canvas-react-512',
    name: 'Kingston Canvas React Plus 512GB microSD',
    category: 'storage',
    subcategory: 'microSD Card',
    retailerLinks: { amazon: 'https://amazon.com/dp/B08WFL2TXB', bestbuy: '' },
    price: { amazon: 52, msrp: 64 },
    keySpecs: { capacity: '512GB', readSpeed: '285 MB/s (UHS-II)', writeSpeed: '165 MB/s', rating: 'U3, V90, A1, UHS-II', warranty: 'Lifetime limited' },
    bestFor: 'UHS-II speeds for compatible devices', rating: 4.3
  },
  {
    id: 'teamgroup-ultra-a2-1tb',
    name: 'TeamGroup ULTRA A2 V30 1TB microSD',
    category: 'storage',
    subcategory: 'microSD Card',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C1234567', walmart: '' },
    price: { amazon: 72, walmart: 75, msrp: 85 },
    keySpecs: { capacity: '1TB', readSpeed: '100 MB/s', writeSpeed: '90 MB/s', rating: 'U3, V30, A2, UHS-I', warranty: 'Lifetime limited' },
    bestFor: 'Budget 1TB option, A2 rated for apps', rating: 4.1
  },

  // === DOCKS & HUBS (10) ===
  {
    id: 'valve-official-dock',
    name: 'Valve Steam Deck Docking Station (Official)',
    category: 'dock',
    subcategory: 'Official Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BFCV2TJX', bestbuy: '', walmart: '', direct: 'https://store.steampowered.com/steamdeckdock' },
    price: { amazon: 89, direct: 89, msrp: 89 },
    keySpecs: { hdmi: 'HDMI 2.0 (4K@60Hz)', usbA: '3× USB-A 3.0', ethernet: 'Gigabit', pdPassthrough: 'USB-C PD passthrough', firmware: 'Firmware updates via Deck' },
    bestFor: 'Official support, firmware updates, guaranteed compatibility', rating: 4.4
  },
  {
    id: 'jsaux-5in1-dock',
    name: 'JSAUX Upgraded 5-in-1 Dock',
    category: 'dock',
    subcategory: '3rd Party Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B5VJV4FC', jsaux: 'https://jsaux.com/dock' },
    price: { amazon: 45, jsaux: 40, msrp: 59 },
    keySpecs: { hdmi: 'HDMI 2.1 (4K@120Hz)', usbA: '3× USB-A 3.0', ethernet: 'Gigabit', pdPassthrough: '100W PD passthrough', design: 'Compact, no stand' },
    bestFor: 'Best value, HDMI 2.1 for 120Hz 4K', rating: 4.6
  },
  {
    id: 'jsaux-m2-dock',
    name: 'JSAUX HB0604 6-in-1 with M.2 SSD Slot',
    category: 'dock',
    subcategory: '3rd Party Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C1234567', jsaux: 'https://jsaux.com/hb0604' },
    price: { amazon: 99, jsaux: 95, msrp: 119 },
    keySpecs: { hdmi: 'HDMI 2.0 (4K@60Hz)', usbA: '2× USB-A 3.0', ethernet: 'Gigabit', pdPassthrough: '100W PD', ssdSlot: 'M.2 2230/2242 NVMe slot', design: 'With stand' },
    bestFor: 'Built-in storage expansion, all-in-one solution', rating: 4.5
  },
  {
    id: 'jsaux-rgb-cooling-dock',
    name: 'JSAUX 7-in-1 RGB Cooling Dock HB0705',
    category: 'dock',
    subcategory: '3rd Party Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C1234568', jsaux: 'https://jsaux.com/hb0705' },
    price: { amazon: 59, jsaux: 55, msrp: 69 },
    keySpecs: { hdmi: 'HDMI 2.0 (4K@60Hz)', usbA: '3× USB-A 3.0', ethernet: 'Gigabit', pdPassthrough: '100W PD', cooling: 'Magnetic cooling fan', rgb: 'RGB lighting' },
    bestFor: 'Active cooling for extended docked sessions', rating: 4.3
  },
  {
    id: 'benq-gr10',
    name: 'BenQ GR10 Gaming Dock',
    category: 'dock',
    subcategory: 'Premium Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C1234569', bestbuy: '' },
    price: { amazon: 109, msrp: 129 },
    keySpecs: { hdmi: 'HDMI 2.1 (4K@120Hz + VRR)', usbA: '3× USB-A 3.2', ethernet: '2.5GbE', pdPassthrough: '100W PD', design: 'Premium aluminum build' },
    bestFor: 'Premium 4K VRR gaming, 2.5Gb Ethernet', rating: 4.4
  },
  {
    id: 'syntech-6in1',
    name: 'Syntech 6-in-1 Docking Station',
    category: 'dock',
    subcategory: 'Budget Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B1234560', walmart: '' },
    price: { amazon: 39, walmart: 35, msrp: 49 },
    keySpecs: { hdmi: 'HDMI 2.0 (4K@60Hz)', usbA: '3× USB-A 3.0', ethernet: 'Gigabit', pdPassthrough: '65W PD', design: 'With stand' },
    bestFor: 'Best budget dock with stand', rating: 4.2
  },
  {
    id: 'anker-6in1-hub',
    name: 'Anker 6-in-1 USB-C Hub A83S1',
    category: 'dock',
    subcategory: 'Portable Hub',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C5P12345', bestbuy: '' },
    price: { amazon: 25, msrp: 35 },
    keySpecs: { hdmi: 'HDMI 2.0 (4K@60Hz)', usbA: '2× USB-A 3.0', ethernet: '—', pdPassthrough: '65W PD', design: 'Ultra-portable, cable-attached' },
    bestFor: 'Ultra-portable travel hub', rating: 4.3
  },
  {
    id: 'ugreen-6in1-hub',
    name: 'UGREEN 6-in-1 USB-C Hub',
    category: 'dock',
    subcategory: 'Portable Hub',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C1234570', bestbuy: '' },
    price: { amazon: 46, msrp: 59 },
    keySpecs: { hdmi: 'HDMI 2.0 (4K@60Hz)', usbA: '3× USB-A 3.0', ethernet: 'Gigabit', pdPassthrough: '100W PD', design: 'Aluminum, cable-attached' },
    bestFor: 'Premium portable hub with Ethernet', rating: 4.4
  },
  {
    id: 'razer-tb4-dock',
    name: 'Razer Thunderbolt 4 Dock Chroma',
    category: 'dock',
    subcategory: 'Thunderbolt Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B09W123456', bestbuy: '' },
    price: { amazon: 329, msrp: 369 },
    keySpecs: { thunderbolt: '4× Thunderbolt 4', usbA: '3× USB-A 3.2', ethernet: '2.5GbE', pdPassthrough: '90W PD', display: 'Dual 4K@60Hz or single 8K', rgb: 'Razer Chroma RGB' },
    bestFor: 'MSI Claw TB4 eGPU support, dual 4K', rating: 4.2
  },
  {
    id: 'asus-rog-dock',
    name: 'ASUS ROG 65W Charger Dock',
    category: 'dock',
    subcategory: 'Official Dock',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0C5P67890', bestbuy: '', walmart: '', direct: 'https://asus.com/rog-dock' },
    price: { amazon: 45, direct: 45, msrp: 59 },
    keySpecs: { hdmi: 'HDMI 2.0 (4K@60Hz)', usbA: '1× USB-A 3.0', ethernet: '—', pdPassthrough: '65W integrated charger', design: 'Compact with charger' },
    bestFor: 'ROG Ally X official, integrated charger', rating: 4.1
  },

  // === PERIPHERALS (10) ===
  {
    id: 'gulikit-sd02',
    name: 'GuliKit Hall Effect Joystick Kit (Steam Deck)',
    category: 'peripheral',
    subcategory: 'Joystick Replacement',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BYJ12345', bestbuy: '' },
    price: { amazon: 29, msrp: 35 },
    keySpecs: { type: 'Hall Effect sensor', compatibility: 'Steam Deck / Deck OLED', install: 'No soldering required', tools: 'T6 Torx screwdriver included', warranty: '1 year' },
    bestFor: 'Permanent stick drift fix for Steam Deck', rating: 4.7
  },
  {
    id: '8bitdo-ultimate-bt',
    name: '8BitDo Ultimate Bluetooth Controller',
    category: 'peripheral',
    subcategory: 'External Controller',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B9X12345', bestbuy: '', walmart: '' },
    price: { amazon: 69, bestbuy: 69, msrp: 79 },
    keySpecs: { type: 'Bluetooth + 2.4GHz', sticks: 'Hall Effect joysticks', battery: '22 hours', charging: 'USB-C + charging dock included', buttons: 'Customizable back paddles', weight: '228g' },
    bestFor: 'Best external controller for docked play', rating: 4.6
  },
  {
    id: '8bitdo-ultimate-2c',
    name: '8BitDo Ultimate 2C',
    category: 'peripheral',
    subcategory: 'External Controller',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0D1234567', bestbuy: '', walmart: '' },
    price: { amazon: 29, msrp: 34 },
    keySpecs: { type: 'Wired USB-C', sticks: 'Hall Effect joysticks', buttons: 'Standard layout', weight: '210g', cable: 'Included USB-C cable' },
    bestFor: 'Best budget external controller', rating: 4.3
  },
  {
    id: 'arzopa-z1fc',
    name: 'Arzopa Z1FC 16.1" Portable Monitor',
    category: 'peripheral',
    subcategory: 'Portable Monitor',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BYJ12346', bestbuy: '', walmart: '' },
    price: { amazon: 109, msrp: 139 },
    keySpecs: { size: '16.1"', resolution: '1920×1080', refresh: '144Hz', panel: 'IPS', brightness: '300 nits', ports: '2× USB-C + 1× mini HDMI', weight: '780g', power: 'USB-C powered' },
    bestFor: 'Best value high-refresh portable monitor', rating: 4.5
  },
  {
    id: 'uperfect-156',
    name: 'UPERFECT 15.6" Portable Monitor',
    category: 'peripheral',
    subcategory: 'Portable Monitor',
    retailerLinks: { amazon: 'https://amazon.com/dp/B08WFL2TXC', bestbuy: '', walmart: '' },
    price: { amazon: 69, walmart: 72, msrp: 99 },
    keySpecs: { size: '15.6"', resolution: '1920×1080', refresh: '60Hz', panel: 'IPS', brightness: '250 nits', ports: '2× USB-C + 1× mini HDMI', weight: '680g', power: 'USB-C powered' },
    bestFor: 'Ultra-budget portable second screen', rating: 4.2
  },
  {
    id: 'jsaux-modcase',
    name: 'JSAUX ModCase for Steam Deck/ROG Ally',
    category: 'peripheral',
    subcategory: 'Case & Grip',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BYJ12347', jsaux: 'https://jsaux.com/modcase' },
    price: { amazon: 29, jsaux: 27, msrp: 39 },
    keySpecs: { compatibility: 'Steam Deck OLED / ROG Ally X', type: 'Protective + modular', modules: 'Kickstand, strap, cooling fan attach', material: 'TPU + polycarbonate', weight: '130g' },
    bestFor: 'Modular protection with expandability', rating: 4.4
  },
  {
    id: 'skullco-grip',
    name: 'Skull & Co. GripCase',
    category: 'peripheral',
    subcategory: 'Case & Grip',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B9X12346', bestbuy: '', walmart: '' },
    price: { amazon: 24, msrp: 29 },
    keySpecs: { compatibility: 'Steam Deck OLED', type: 'Grip + protection', grips: '3 interchangeable grip sizes', material: 'Soft TPU', weight: '90g' },
    bestFor: 'Ergonomic grips at budget price', rating: 4.3
  },
  {
    id: 'jsaux-matte-screen',
    name: 'JSAUX Anti-Glare Matte Screen Protector',
    category: 'peripheral',
    subcategory: 'Screen Protector',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BYJ12348', jsaux: 'https://jsaux.com/screen-protector' },
    price: { amazon: 12, jsaux: 10, msrp: 16 },
    keySpecs: { type: 'Matte anti-glare', hardness: '9H tempered glass', thickness: '0.3mm', transmittance: '95%', compatibility: 'Steam Deck OLED / ROG Ally X / Legion Go' },
    bestFor: 'Outdoor gaming, anti-fingerprint, glare reduction', rating: 4.5
  },
  {
    id: 'amfilm-onetouch',
    name: 'amFilm OneTouch Glass Screen Protector',
    category: 'peripheral',
    subcategory: 'Screen Protector',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0B1234561', bestbuy: '' },
    price: { amazon: 13, msrp: 17 },
    keySpecs: { type: 'Crystal clear glossy', hardness: '9H tempered glass', thickness: '0.33mm', transmittance: '99%', install: 'OneTouch alignment tray included' },
    bestFor: 'Maximum clarity, easy install, dark room gaming', rating: 4.6
  },
  {
    id: 'jsaux-cooling-fan',
    name: 'JSAUX External Cooling Fan',
    category: 'peripheral',
    subcategory: 'Cooling',
    retailerLinks: { amazon: 'https://amazon.com/dp/B0BYJ12349', jsaux: 'https://jsaux.com/cooling-fan' },
    price: { amazon: 39, jsaux: 35, msrp: 49 },
    keySpecs: { type: 'Clip-on external fan', speed: '3,500 RPM', noise: '28dBA', power: 'USB-C powered', tempReduction: '8-12°C', compatibility: 'Universal (Steam Deck/Ally/Legion Go)' },
    bestFor: 'Thermal throttling prevention, summer gaming', rating: 4.0
  },
];

// Utility functions
export const getProductsByCategory = (category: string) => products.filter(p => p.category === category);
export const getProductById = (id: string) => products.find(p => p.id === id);
export const getBestPrice = (product: Product) => {
  const prices = Object.values(product.price).filter(v => typeof v === 'number' && v > 0) as number[];
  return Math.min(...prices);
};
export const getRetailerCount = (product: Product) => Object.values(product.retailerLinks).filter(Boolean).length;
export const categories = [
  { id: 'console', label: 'Consoles', icon: 'Gamepad2' },
  { id: 'power', label: 'Power Solutions', icon: 'Zap' },
  { id: 'storage', label: 'Storage', icon: 'HardDrive' },
  { id: 'dock', label: 'Docks & Hubs', icon: 'Monitor' },
  { id: 'peripheral', label: 'Peripherals', icon: 'Gamepad' },
];

export const softwareTools = [
  { name: 'EmuDeck', url: 'https://www.emudeck.com', description: 'All-in-one emulation setup for Steam Deck and Windows handhelds', category: 'Emulation', free: true },
  { name: 'Decky Loader', url: 'https://decky.xyz', description: 'Plugin loader for Steam Deck with 50+ community plugins', category: 'Utility', free: true },
  { name: 'ProtonDB', url: 'https://www.protondb.com', description: 'Community game compatibility database for Linux/SteamOS', category: 'Compatibility', free: true },
  { name: 'Handheld Companion', url: 'https://handheldcompanion.com', description: 'TDP control, fan curves, and performance overlay for Windows handhelds', category: 'Performance', free: true },
  { name: 'Lossless Scaling', url: 'https://store.steampowered.com/app/993090', description: 'AI frame generation tool — double your FPS for $7', category: 'Performance', free: false, price: '$6.99' },
  { name: 'Moonlight', url: 'https://moonlight-stream.org', description: 'Open-source NVIDIA GameStream client for remote play', category: 'Streaming', free: true },
  { name: 'Sunshine', url: 'https://app.lizardbyte.dev/Sunshine', description: 'Self-hosted game stream host for Moonlight', category: 'Streaming', free: true },
  { name: 'chiaki-ng', url: 'https://streetpea.github.io/chiaki-ng', description: 'PS4/PS5 remote play client for Steam Deck', category: 'Streaming', free: true },
  { name: 'Win11Debloat', url: 'https://github.com/Raphire/Win11Debloat', description: 'PowerShell script to remove bloatware and optimize Windows 11', category: 'Utility', free: true },
  { name: 'Steam ROM Manager', url: 'https://github.com/SteamGridDB/steam-rom-manager', description: 'Add emulated games to Steam with artwork', category: 'Emulation', free: true },
];

export const affiliatePrograms = [
  { name: 'Amazon Associates', commission: '1-4%', cookie: '24 hours', network: 'Direct', bestFor: 'Broad product coverage, highest conversion', rating: 4.5 },
  { name: 'JSAUX Direct', commission: '7%', cookie: '30 days', network: 'UpPromote/Impact', bestFor: 'Handheld accessories, highest commission', rating: 4.8 },
  { name: 'Humble Bundle Partner', commission: '8-10%', cookie: '7-30 days', network: 'Direct', bestFor: 'Game bundles, digital content', rating: 4.6 },
  { name: 'Anker Affiliate', commission: '8%', cookie: '30 days', network: 'Direct', bestFor: 'Power banks and chargers', rating: 4.4 },
  { name: 'Best Buy Affiliate', commission: '0.5-1%', cookie: '1 day', network: 'Impact', bestFor: 'Brand recognition, price anchoring', rating: 3.0 },
  { name: 'Walmart Affiliate', commission: '1-3%', cookie: '3 days', network: 'Impact', bestFor: 'Budget-conscious shoppers', rating: 3.5 },
  { name: 'B&H Photo', commission: '2-8%', cookie: '60 days', network: 'Direct', bestFor: 'High-ticket items, long cookie', rating: 4.3 },
  { name: 'Newegg Affiliate', commission: '0.5-2.5%', cookie: '7 days', network: 'CJ', bestFor: 'Tech-savvy audience', rating: 3.5 },
];
